using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SingleLaneGame : MonoBehaviour
{
    public GameObject card;
    public GameObject canvas;
    public SingleLanePlayer singleLanePlayer;

    private void Start()
    {
        SetHand();
    }

    private void SetHand()
    {
        singleLanePlayer.SetHand(card, canvas);
    }
}
