using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class SingleLaneElement : MonoBehaviour
{
    public string selectedCard;
    public Dictionary<int, int> handCard;
    private List<int> startingCardList;

    public  SingleLaneElement()
    {
        selectedCard = "";
        handCard = new Dictionary<int, int>();
        startingCardList = new List<int>(new int[] { 0, 1, 2, 3, 4 });
    }

    public void SetHand()
    {
        for (int i = 0; i < startingCardList.Count; i++)
        {
            int card_kind = startingCardList[i];
            handCard.Add(i, card_kind);
        }
    }
}
